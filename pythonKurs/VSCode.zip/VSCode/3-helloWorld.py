# For å skrive noe til skjerm, brukes funksjonen print. 
# Se på eksempelet i hefte og skriv noe til skjerm selv.
