# Input brukes til å la brukeren skrive inn en verdi til en variabel
# Se på eksempelet i hefte og lag din egen variabel der brukeren skriver inn verdien. Skriv denne til skjerm