# I Python bruker man ofte variabler. 
# Se på eksemplene i hefte og lag et par variabler, skriv til skjerm og endre datatypen på disse.