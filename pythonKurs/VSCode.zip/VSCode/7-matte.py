# Her skal vi kombinere alt vi har lært til nå for å utføre matematiske regnestykker.
# Se på eksemplene i hefte og lag deg noen variabler med både en satt verdi og der bruker skriver inn en verdi.
# Bruk operatorer og regn med disse. Skriv resultatet til skjerm