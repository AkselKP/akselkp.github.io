# Python har mange operatorer, men vi skal fokusere på +-*/.
# Se på eksemplene i hefte og bruk hver variabel minst en gang. Skriv dette til skjerm